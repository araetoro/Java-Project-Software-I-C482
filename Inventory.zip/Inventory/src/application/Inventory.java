package application;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.*;

public class Inventory extends Application {

	@Override
	public void start(Stage primaryStage) {

//	@Override
//	public void start(Stage primaryStage) {
		//Populating Associated Parts List
		Products prodObj = new Products();
		
		ArrayList<String> product1 = new ArrayList<String>();
		product1.add("Product 1");
		product1.add("Parts 1");
		prodObj.addAssociatedPart(product1);
		
		ArrayList<String> product2 = new ArrayList<String>();
		product2.add("Product 2");
		product2.add("Parts 2");
		prodObj.addAssociatedPart(product2);
		
		ArrayList<String> product3 = new ArrayList<String>();
		product3.add("Product 3");
		product3.add("Parts 3");
		prodObj.addAssociatedPart(product3);
		
		//Cancel Button
		Button cancel = new Button("Cancel");
		Button cancel2 = new Button("Cancel");
		Button cancel3 = new Button("Cancel");
		Button cancel4 = new Button("Cancel");
		
		Button savePart = new Button("Save");
		
		
		//Exit Button
		Button exitButton = new Button("Exit");
		exitButton.setOnAction(e->Platform.exit());
		
		//Add Part Screen
//		AddPartScreen aparts = new AddPartScreen();
//		Scene apartScene = aparts.sceneView1(cancel2,savePart);
		
		//Add Product Screen
//		AddProductScreen aprods = new AddProductScreen();
//		Scene aprodScene = aprods.sceneView1(cancel3);
//		
		
		//Modify Product Screen
//		ModifyProductScreen mprods = new ModifyProductScreen();
//		Scene mprodScene = mprods.sceneView1(cancel);
		
		//

		//
		//Main Parts Pane
		TextField searchbox = new TextField();
		HBox hb = new HBox();
		hb.getChildren().addAll(searchbox);
		hb.setSpacing(10);
		
		//Main Parts Buttons		
		Button addPartButton = new Button();
		addPartButton.setText("Add");
		addPartButton.setOnAction(e ->{
			AddPartScreen aparts = new AddPartScreen();
			Scene apartScene = aparts.sceneView1(cancel2,savePart);
			primaryStage.setScene(apartScene);
			});	

		Button modifyPartButton = new Button();

		Button deletePartButton = new Button();
		deletePartButton.setText("Delete");
		deletePartButton.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				System.out.println("Deleting...");
			}
		});
		
		//Main Products Pane
		TextField searchProdBox = new TextField();
		HBox searchProdHb = new HBox();
		searchProdHb.getChildren().addAll(searchProdBox);
		searchProdHb.setSpacing(10);
		
		//Main Product Buttons
		
		Button addProdButton = new Button();
		addProdButton.setText("Add");
		addProdButton.setOnAction(e ->{
			AddProductScreen aprods = new AddProductScreen();
			Scene aprodScene = aprods.sceneView1(cancel3);
			primaryStage.setScene(aprodScene);
		});	
		
		
		Button modifyProdButton = new Button();

		Button deleteProdButton = new Button();
		deleteProdButton.setText("Delete");
		deleteProdButton.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				System.out.println("Deleting...");
			}
		});
		
		//Text objects
		Text title = new Text("Inventory Management System");
		title.setFont(Font.font("Tahoma", 20));
		
		Text parts = new Text("Parts");
		parts.setFont(Font.font("Tahoma",20));
		
		Text products = new Text("Products");
		products.setFont(Font.font("Tahoma",20));
		
//		Label response = new Label("");
//		Label response2 = new Label("");
		
		//Parts FlowPane
		FlowPane partsPane = new FlowPane();
		partsPane.setAlignment(Pos.CENTER);
//		
//		ObservableList<Parts> allPartsList = 
//	FXCollections.observableArrayList(
//			new Parts (1,"Part 1",5,5.00),
//			new Parts (2,"Part 2",10,10.00),
//			new Parts (3,"Part 3",12,15.00)
//			);
		
		PartData partData = new PartData();
		ObservableList<Parts> allPartsList = partData.getPartsList();

		TableView<Parts> tvParts;
		
		tvParts = new TableView<Parts>(allPartsList);
		
		TableColumn<Parts, String> pId = new TableColumn<>("Part Id");
		pId.setCellValueFactory(new PropertyValueFactory<>("partId"));
		tvParts.getColumns().add(pId);
		
		TableColumn<Parts, String> pName = new TableColumn<>("Part Name");
		pName.setCellValueFactory(new PropertyValueFactory<>("partName"));
		tvParts.getColumns().add(pName);
		
		TableColumn<Parts, String> iLevel = new TableColumn<>("Inventory Level");
		iLevel.setCellValueFactory(new PropertyValueFactory<>("inventoryLevel"));
		tvParts.getColumns().add(iLevel);
		
		TableColumn<Parts, Double> cPerUnit = new TableColumn<>("Cost Per Unit");
		cPerUnit.setCellValueFactory(new PropertyValueFactory<>("costPerUnit"));
		tvParts.getColumns().add(cPerUnit);
		
		tvParts.setPrefWidth(330);
		tvParts.setPrefHeight(115);

		partsPane.getChildren().addAll(tvParts);
		
		//Search Parts Filter
		FilteredList<Parts> filteredParts = new FilteredList<>(allPartsList, p -> true);
		
			searchbox.textProperty().addListener((observable, oldValue, newValue)->{
				filteredParts.setPredicate(part ->{
				if(newValue == null || newValue.isEmpty()) {
					return true;
				}
				
				String lowerCaseFilter = newValue.toLowerCase();
			
				if (part.getPartName().toLowerCase().contains(lowerCaseFilter)) {
				return true;
				}
				return false;
				});
			});
			SortedList<Parts> sortedParts = new SortedList<>(filteredParts);
//			tvParts.setItems(sortedParts);
					
			Button searchPartsButton = new Button();
			searchPartsButton.setText("Search");
			searchPartsButton.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				tvParts.setItems(sortedParts);
			}
		});
		
		
				//Products FlowPane
				FlowPane productsPane = new FlowPane();
				productsPane.setAlignment(Pos.CENTER);
				
//				ObservableList<Products> allProductsList = 
//			FXCollections.observableArrayList(
//					new Products (1,"Product 1",5,5.00),
//					new Products (2,"Product 2",10,10.00),
//					new Products (3,"Product 3",12,15.00)
//					);
				ProductData proddata = new ProductData();
				ObservableList<Products> allProductsList = proddata.getProductList();
				
				
					
				TableView<Products> tvProducts;
				
				tvProducts = new TableView<Products>(allProductsList);
				
				TableColumn<Products, String> prodId = new TableColumn<>("Produt Id");
				prodId.setCellValueFactory(new PropertyValueFactory<>("productId"));
				tvProducts.getColumns().add(prodId);
				
				TableColumn<Products, String> prodName = new TableColumn<>("Product Name");
				prodName.setCellValueFactory(new PropertyValueFactory<>("productName"));
				tvProducts.getColumns().add(prodName);
				
				TableColumn<Products, String> iLevelProd = new TableColumn<>("Inventory Level");
				iLevelProd.setCellValueFactory(new PropertyValueFactory<>("inventoryLevelProd"));
				tvProducts.getColumns().add(iLevelProd);
				
				TableColumn<Products, Double> cPerUnitProd = new TableColumn<>("Cost Per Unit");
				cPerUnitProd.setCellValueFactory(new PropertyValueFactory<>("costPerUnitProd"));
				tvProducts.getColumns().add(cPerUnitProd);
				
				tvProducts.setPrefWidth(360);
				tvProducts.setPrefHeight(115);
				
				productsPane.getChildren().addAll(tvProducts);
						
						//Search Products Filter
						FilteredList<Products> filteredProducts = new FilteredList<>(allProductsList, p -> true);
						
							searchProdBox.textProperty().addListener((observable, oldValue, newValue)->{
								filteredProducts.setPredicate(product ->{
								if(newValue == null || newValue.isEmpty()) {
									return true;
								}
								
								String lowerCaseFilter = newValue.toLowerCase();
							
								if (product.getProductName().toLowerCase().contains(lowerCaseFilter)) {
								return true;
								}
								return false;
								});
							});
							SortedList<Products> sortedProducts = new SortedList<>(filteredProducts);
//							tvParts.setItems(sortedParts);
									
							Button searchProdButton = new Button();
							searchProdButton.setText("Search");
							searchProdButton.setOnAction(new EventHandler<ActionEvent>() {
							
							@Override
							public void handle(ActionEvent event) {
								tvProducts.setItems(sortedProducts);
							}
						});
		
	
						
		//Grid
		GridPane root = new GridPane();
		root.setHgap(10);
		root.setVgap(10);
		root.setPadding(new Insets(25,25,25,25));
		root.setGridLinesVisible(false);
		//Parts		
		root.add(title, 0, 0);
		root.add(parts, 1, 3);
		root.add(searchPartsButton,3,3);
		root.add(hb, 4, 3,2,1);
		root.add(partsPane, 1, 4,5,1);
		root.add(addPartButton, 2, 6);
		root.add(modifyPartButton, 3, 6);
		root.add(deletePartButton, 4, 6);
		//Products
		root.add(products, 8, 3);
		root.add(searchProdButton,10,3);
		root.add(searchProdHb, 11,3);
		root.add(productsPane, 7, 4, 5, 1);
		root.add(addProdButton, 9, 6);
		root.add(modifyProdButton, 10, 6);
		root.add(deleteProdButton, 11, 6);
		root.add(exitButton, 12, 7);
		
		Scene inventoryScene = new Scene(root, 1500, 500);

		primaryStage.setTitle("Inventory Manager");
		primaryStage.setScene(inventoryScene);
		primaryStage.show();
		
		
		//Cancel Button Action
		cancel.setOnAction(e-> {
			primaryStage.close();
			primaryStage.setScene(inventoryScene);
			primaryStage.show();		
		});
		
		cancel2.setOnAction(e-> {
			primaryStage.close();
			primaryStage.setScene(inventoryScene);
			primaryStage.show();
		});
		
		cancel3.setOnAction(e-> {
			primaryStage.close();
			primaryStage.setScene(inventoryScene);
			primaryStage.show();
		});
		
		cancel4.setOnAction(e-> primaryStage.setScene(inventoryScene));
		
		
		savePart.setOnAction(e->{
			primaryStage.setScene(inventoryScene);
		});
		
		
		
		//Delete Part Button Action
		deletePartButton.setOnAction(e->{
			Parts selectedItem = tvParts.getSelectionModel().getSelectedItem();
			int selectedId = selectedItem.getPartId();
			//String deleteName = selectedItem.getPartName();
			partData.deletePart(selectedId);
		});
		
		
		//Delete Product Button Action
		deleteProdButton.setOnAction(e->{
			Products selectedItem = tvProducts.getSelectionModel().getSelectedItem();
			int selectedId = selectedItem.getProductId();
			//String deleteName = selectedItem.getProductName();
			proddata.deleteProduct(selectedId);
		});
			
		//Modify Part Button Action
		modifyPartButton.setText("Modify");
		modifyPartButton.setOnAction(e -> {
		Parts selectedItem = tvParts.getSelectionModel().getSelectedItem();
		int selectedId = selectedItem.getPartId();
		String selectedName = selectedItem.getPartName();
		int selectedInv = selectedItem.getInventoryLevel(); 
		double selectedCost= selectedItem.getCostPerUnit();
		int selectedMax = selectedItem.getMax();
		int selectedMin = selectedItem.getMin();
		
		//Modify Part Screen
		ModifyPartScreen mparts = new ModifyPartScreen();
		
		if(selectedItem instanceof InHouse) {
		int selectedMachineId = ((InHouse) selectedItem).getMachineId();
		Scene mpartScene = mparts.sceneView1(cancel4, selectedId, selectedName, selectedInv, selectedCost, selectedMax,selectedMin, selectedMachineId);
		primaryStage.setScene(mpartScene);
		}
		
		else if(selectedItem instanceof Outsourced) {
		String selectedCompanyName = ((Outsourced) selectedItem).getCompanyName();
		Scene mpartScene = mparts.sceneView1(cancel4, selectedId, selectedName, selectedInv, selectedCost, selectedMax,selectedMin, selectedCompanyName);
		primaryStage.setScene(mpartScene);
	
		}
		});
		
		//Modify Product ButtonAction
		modifyProdButton.setText("Modify");
		modifyProdButton.setOnAction(e ->{
			
			Products selectedItem = tvProducts.getSelectionModel().getSelectedItem();
			
			int selectedId = selectedItem.getProductId();
			String selectedName = selectedItem.getProductName();
			int selectedInv = selectedItem.getInventoryLevelProd(); 
			double selectedCost= selectedItem.getCostPerUnitProd();
			int selectedMax = selectedItem.getMaxProd();
			int selectedMin = selectedItem.getMinProd();	
			ModifyProductScreen mprods = new ModifyProductScreen();
			Scene mprodScene = mprods.sceneView1(cancel, selectedId, selectedName, selectedInv, selectedCost, selectedMax,selectedMin);
			primaryStage.setScene(mprodScene);
			
		});

	}
	
	
public static void main(String[] args) {
		launch(args);	
	}
}
