package application;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleDoubleProperty;



abstract class Parts {
	
	private SimpleIntegerProperty partId = new SimpleIntegerProperty(0);
	
	private SimpleStringProperty partName = new SimpleStringProperty("");
	
	private SimpleIntegerProperty inventoryLevel = new SimpleIntegerProperty(0);
	
	private SimpleDoubleProperty costPerUnit = new SimpleDoubleProperty(0);
	
	private SimpleIntegerProperty min = new SimpleIntegerProperty(0);
	
	private SimpleIntegerProperty max = new SimpleIntegerProperty(0);
	
	public Parts() {
		this(0,"",0,0,0,0);
	}
	
	public Parts(int partId, String partName, int inventoryLevel, double d, int min, int max) {
		setPartId(partId);
		setPartName(partName);
		setInventoryLevel(inventoryLevel);
		setCostPerUnit(d);	
		setMin(min);
		setMax(max);
	}
	
	public int getPartId() {
		return partId.get();
	}
	
	public void setPartId(int pId) {
		partId.set(pId);
	}
	
	public String getPartName() {
		return partName.get();
	}
	
	public void setPartName(String pName) {
		partName.set(pName);
	}
	
	public int getInventoryLevel() {
		return inventoryLevel.get();
	}
	
	public void setInventoryLevel(int iLevel) {
		inventoryLevel.set(iLevel);
	}
	
	public Double getCostPerUnit() {
		return costPerUnit.get();
	}
	
	public void setCostPerUnit(Double cPerUnit) {
		costPerUnit.set(cPerUnit);
	}
	
	public int getMin() {
		return min.get();
	}
	
	public void setMin(int mn) {
		min.set(mn);
	}
	
	public int getMax() {
		return max.get();
	}
	
	public void setMax(int mx) {
		max.set(mx);
	}
}
