package application;

import javafx.beans.property.SimpleStringProperty;

public class Outsourced extends Parts{
	
	private SimpleStringProperty companyName = new SimpleStringProperty("");
	
	public Outsourced() {
		this(0,"",0,0,0,0,"");
	}
	
	public Outsourced(int partId, String partName, int inventoryLevel, double d, int min, int max, String companyName) {
		setPartId(partId);
		setPartName(partName);
		setInventoryLevel(inventoryLevel);
		setCostPerUnit(d);
		setMin(min);
		setMax(max);
		setCompanyName(companyName);
	}
	
	public String getCompanyName() {
		return companyName.get();
	}
	
	public void setCompanyName(String cName) {
		companyName.set(cName);

	}
}
