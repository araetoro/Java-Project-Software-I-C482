package application;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.*;

public class AddProductScreen  {
	
public  Scene sceneView1(Button cancel3) {
		
	ProductData prodData = new ProductData();
	int assignProdId = prodData.getProductList().size();
	
	
		//Text objects
		Text addProductText = new Text("Add Product");
		addProductText.setFont(Font.font("Tahoma", 20));
		Text idText = new Text("ID");
		Text nameText = new Text("Name");
		Text invText = new Text("Inv");
		Text costText = new Text("Price");
		Text maxText = new Text("Max");
		Text minText = new Text("Min");
		
		TextField idTextField = new TextField();
		idTextField.setEditable(false);
		TextField searchboxTextField = new TextField();
		TextField nameTextField = new TextField();
		TextField invTextField = new TextField();
		TextField costTextField = new TextField();
		TextField maxTextField = new TextField();
		TextField minTextField = new TextField();

		idTextField.setText(Integer.toString(assignProdId+1));
		nameTextField.setText("Name");
		invTextField.setText("0");
		costTextField.setText("Price/Cost");
		maxTextField.setText("Max");
		minTextField.setText("Min");

		HBox idHb = new HBox();
		HBox searchboxHb = new HBox();
		HBox nameHb = new HBox();
		HBox invHb = new HBox();
		HBox costHb = new HBox();
		HBox maxHb = new HBox();
		HBox minHb = new HBox();

		idHb.getChildren().addAll(idTextField);
		searchboxHb.getChildren().addAll(searchboxTextField);
		nameHb.getChildren().addAll(nameTextField);
		invHb.getChildren().addAll(invTextField);
		costHb.getChildren().addAll(costTextField);
		maxHb.getChildren().addAll(maxTextField);
		minHb.getChildren().addAll(minTextField);

		
		searchboxHb.setSpacing(10);
		nameHb.setSpacing(10);
		invHb.setSpacing(5);
		costHb.setSpacing(5);
		maxHb.setSpacing(5);
		minHb.setSpacing(5);
		
//		//Buttons
//		Button searchButton = new Button();
//		searchButton.setText("Search");
//		searchButton.setOnAction(new EventHandler<ActionEvent>(){
//			
//			@Override
//			public void handle(ActionEvent event) {
//				System.out.println("Searching For: " + searchboxTextField.getText());
//			}
//		});
//		
		Button addButton = new Button();
		addButton.setText("Add");

		Button saveButton = new Button();
		saveButton.setText("Save");
		saveButton.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				System.out.println("Saving...");
			}
		});

		Button deleteButton = new Button();
		deleteButton.setText("Delete");
		deleteButton.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent event) {
				System.out.println("Deleting...");
			}
		});
		
		//Total Parts FlowPane
		FlowPane totalPartsPane = new FlowPane();
		totalPartsPane.setAlignment(Pos.CENTER);
		
		//Total Parts Pane
//		ObservableList<Parts> totalPartsList = 
//				FXCollections.observableArrayList(
//						new Parts (1,"Part 1",5,5.00),
//						new Parts (2,"Part 2",10,10.00),
//						new Parts (3,"Part 3",12,15.00)
//						);
////				
				PartData partdata = new PartData();
				ObservableList<Parts> totalPartsList = partdata.getPartsList();
													
							TableView<Parts> tvTotalParts;
							
							tvTotalParts = new TableView<Parts>(totalPartsList);
							
							TableColumn<Parts, String> tprodId = new TableColumn<>("Part Id");
							tprodId.setCellValueFactory(new PropertyValueFactory<>("partId"));
							tvTotalParts.getColumns().add(tprodId);
							
							TableColumn<Parts, String> tprodName = new TableColumn<>("Part Name");
							tprodName.setCellValueFactory(new PropertyValueFactory<>("partName"));
							tvTotalParts.getColumns().add(tprodName);
							
							TableColumn<Parts, String> tiLevelProd = new TableColumn<>("Inventory Level");
							tiLevelProd.setCellValueFactory(new PropertyValueFactory<>("inventoryLevel"));
							tvTotalParts.getColumns().add(tiLevelProd);
							
							TableColumn<Parts, Double> tcPerUnitProd = new TableColumn<>("Cost Per Unit");
							tcPerUnitProd.setCellValueFactory(new PropertyValueFactory<>("costPerUnit"));
							tvTotalParts.getColumns().add(tcPerUnitProd);
							
							tvTotalParts.setPrefWidth(360);
							tvTotalParts.setPrefHeight(115);
							
							TableView.TableViewSelectionModel<Parts> tvSelTotalParts =
							tvTotalParts.getSelectionModel();
							
									
									//Search Products Filter
									FilteredList<Parts> tfilteredParts = new FilteredList<>(totalPartsList, p -> true);
									
									searchboxTextField.textProperty().addListener((observable, oldValue, newValue)->{
											tfilteredParts.setPredicate(product ->{
											if(newValue == null || newValue.isEmpty()) {
												return true;
											}
											
											String lowerCaseFilter = newValue.toLowerCase();
										
											if (product.getPartName().toLowerCase().contains(lowerCaseFilter)) {
											return true;
											}
											return false;
											});
										});
										SortedList<Parts> sortedTotalParts = new SortedList<>(tfilteredParts);
//										tvParts.setItems(sortedParts);
												
										Button searchButton = new Button();
										searchButton.setText("Search");
										searchButton.setOnAction(new EventHandler<ActionEvent>() {
										
										@Override
										public void handle(ActionEvent event) {
											tvTotalParts.setItems(sortedTotalParts);
										}
										
									});	
				totalPartsPane.getChildren().addAll(tvTotalParts);
					
		
		//Associated Parts FlowPane
		FlowPane associatedPartsPane = new FlowPane();
		associatedPartsPane.setAlignment(Pos.CENTER);
		
		
		ObservableList<Parts> associatedPartsList = FXCollections.observableArrayList(
//				new InHouse (0,"",0,0, 0,0,0),
//				new Outsourced (0,"",0,0,0,0,"")
				);
											
					TableView<Parts> tvAssociatedParts;
					
					tvAssociatedParts = new TableView<Parts>(associatedPartsList);
					
					TableColumn<Parts, String> dprodId = new TableColumn<>("Part Id");
					dprodId.setCellValueFactory(new PropertyValueFactory<>("partId"));
					tvAssociatedParts.getColumns().add(dprodId);
					
					TableColumn<Parts, String> dprodName = new TableColumn<>("Part Name");
					dprodName.setCellValueFactory(new PropertyValueFactory<>("partName"));
					tvAssociatedParts.getColumns().add(dprodName);
					
					TableColumn<Parts, String> diLevelProd = new TableColumn<>("Inventory Level");
					diLevelProd.setCellValueFactory(new PropertyValueFactory<>("inventoryLevel"));
					tvAssociatedParts.getColumns().add(diLevelProd);
					
					TableColumn<Parts, Double> dcPerUnitProd = new TableColumn<>("Cost Per Unit");
					dcPerUnitProd.setCellValueFactory(new PropertyValueFactory<>("costPerUnit"));
					tvAssociatedParts.getColumns().add(dcPerUnitProd);
					
					tvAssociatedParts.setPrefWidth(360);
					tvAssociatedParts.setPrefHeight(115);
					
					TableView.TableViewSelectionModel<Parts> tvSelAssociatedParts =
							tvAssociatedParts.getSelectionModel();
					
							
							//Search Parts Filter
							FilteredList<Parts> dfilteredParts = new FilteredList<>(associatedPartsList, p -> true);
							
							searchboxTextField.textProperty().addListener((observable, oldValue, newValue)->{
									dfilteredParts.setPredicate(Part ->{
									if(newValue == null || newValue.isEmpty()) {
										return true;
									}
									
									String lowerCaseFilter = newValue.toLowerCase();
								
									if (Part.getPartName().toLowerCase().contains(lowerCaseFilter)) {
									return true;
									}
									return false;
									});
								});
								SortedList<Parts> sortedAssociatedParts = new SortedList<>(dfilteredParts);
//								tvParts.setItems(sortedParts);
										
								Button search = new Button();
								search.setText("Search");
								search.setOnAction(new EventHandler<ActionEvent>() {
								
								@Override
								public void handle(ActionEvent event) {
									tvAssociatedParts.setItems(sortedAssociatedParts);
								}
								
							});	
		associatedPartsPane.getChildren().addAll(tvAssociatedParts);
		
		//Add Part Button Action
		addButton.setOnAction(e->{
				Parts selectedItem = tvTotalParts.getSelectionModel().getSelectedItem();
				associatedPartsList.add(selectedItem);
		});
		
		//Delete Product Button Action
		deleteButton.setOnAction(e->{
				Parts selectedItem = tvAssociatedParts.getSelectionModel().getSelectedItem();
				tvAssociatedParts.getItems().remove(selectedItem);
		});
							
		//Grid
		GridPane root = new GridPane();
		root.setHgap(10);
		root.setVgap(10);
		root.setPadding(new Insets(25,25,25,25));
		root.setGridLinesVisible(false);
				
		root.add(addProductText, 0, 0);
		root.add(idText, 1, 1);
		root.add(idHb, 2, 1);
		root.add(nameText, 1, 2);
		root.add(nameHb, 2, 2);
		root.add(invText, 1, 3);
		root.add(invHb, 2, 3);
		root.add(costText, 1, 4);
		root.add(costHb, 2, 4);
		root.add(maxText, 1, 5);
		root.add(maxHb, 2, 5);
		root.add(minText, 3, 5);
		root.add(minHb, 4, 5);
		root.add(searchButton, 6, 0);
		root.add(searchboxHb, 7, 0,3,1);
		root.add(totalPartsPane, 5, 1,5,4);
		root.add(addButton, 11, 5);
		root.add(associatedPartsPane, 5, 6,5,4);
		root.add(deleteButton, 11, 10);
		root.add(saveButton, 10, 11);
		root.add(cancel3, 11, 11);
		
		Scene scene = new Scene(root, 1000, 500);
		
		//Add Product Button Action
//		addButton.setOnAction(e->{
//				
//			//proddata.addProductData(7, "PRODUCT", 7, 7);
//			proddata.addProductData(7, nameTextField.getText(), Integer.parseInt(invTextField.getText()), Integer.parseInt(costTextField.getText()));
//		});
		
		//Create an Alert obj
		Alert a = new Alert(AlertType.NONE, "Your Min Exceeds Your Max");
		Alert aMinEntry = new Alert(AlertType.NONE, "You Must Enter a Product Name, Cost Per Unit, and Inventory");
		Alert aTotalCost = new Alert(AlertType.NONE, "The Cost Of Your Parts Exeeds The Cost Of Your Product");
		
		//Save  Button Action
		saveButton.setOnAction(e->{
			
			double totalCost = 0;
			
			for ( Parts item : tvAssociatedParts.getItems()){
				double costPerUnit = item.getCostPerUnit();
				totalCost = totalCost + costPerUnit;
				}

			if(Integer.parseInt(minTextField.getText()) <= Integer.parseInt(maxTextField.getText()) && !nameTextField.getText().isEmpty() & !costTextField.getText().isEmpty() && !invTextField.getText().isEmpty() & totalCost <=  Double.parseDouble(costTextField.getText())) {
				
			ProductData proddata = new ProductData();
			proddata.addProductData(Integer.parseInt(idTextField.getText()), nameTextField.getText(), Integer.parseInt(invTextField.getText()), Integer.parseInt(costTextField.getText()), Integer.parseInt(minTextField.getText()), Integer.parseInt(maxTextField.getText()));
			String selProdName= nameTextField.getText();
			Products associatedProd = new Products();
			for ( Parts item : tvAssociatedParts.getItems()){
				String selPartName = item.getPartName();
				
				ArrayList<String> newAssociatedParts = new ArrayList<String>();
				newAssociatedParts.add(selProdName);
				newAssociatedParts.add(selPartName);
				
				associatedProd.addAssociatedPart(newAssociatedParts);
			};

			tvAssociatedParts.setItems(associatedPartsList);
			
			
			cancel3.fire();
			}
			else if(Integer.parseInt(minTextField.getText()) > Integer.parseInt(maxTextField.getText())) {
				a.setAlertType(AlertType.WARNING);
				a.show();
			}
			else if(totalCost >  Double.parseDouble(costTextField.getText())) {
				aTotalCost.setAlertType(AlertType.WARNING);
				aTotalCost.show();
			}
			else  {
				aMinEntry.setAlertType(AlertType.WARNING);
				aMinEntry.show();
			}
		});
		
		
		return scene;
	}
	
}

