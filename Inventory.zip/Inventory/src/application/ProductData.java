package application;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class ProductData {

static ObservableList<Products> allProductsList = 
FXCollections.observableArrayList(
		new Products (1,"Product 1",5,5.00, 5, 10),
		new Products (2,"Product 2",10,10.00, 3, 6),
		new Products (3,"Product 3",12,15.00, 7, 14)
		);

public ObservableList<Products> getProductList(){
	return allProductsList;
}

public void addProductData(int id, String prodName, int inventoryLevel, double cost, int min, int max) {
	this.allProductsList.add(new Products (id,prodName, inventoryLevel,cost, min, max));	
}

public void deleteProduct(String deleteName) {
	this.allProductsList.removeIf(allProductsList -> allProductsList.getProductName().contains(deleteName));
	}
public int getsize() {
	return allProductsList.size();
}
public Products getItem(int index) {
	return allProductsList.get(index);
}

public void setProductData(int index, int id, String partName, int inventoryLevel, double cost, int min, int max) {
	this.allProductsList.set(index, new Products (id, partName, inventoryLevel,cost, min, max));	

}

public void deleteProduct(int selectedId) {
	this.allProductsList.removeIf(allProductsList -> allProductsList.getProductId() == selectedId);
}
}
