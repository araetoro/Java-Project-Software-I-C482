package application;

import javax.swing.text.html.HTMLDocument.Iterator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PartData {

	static ObservableList<Parts> allPartsList = 
			FXCollections.observableArrayList(
					new InHouse (1,"Parts 1",5,5.00, 2,4,49),
					new Outsourced (2,"Parts 2",10,10.00, 4,8,"Koola"),
					new InHouse (3,"Parts 3",12,15.00, 3,6,62),
					new Outsourced (4,"Part 4",10,10.00, 5, 10, "Beta")
					);

			public ObservableList<Parts> getPartsList(){
				return allPartsList;
			}
			
			public void addInHousePartData(int id, String partName, int inventoryLevel, double cost, int min, int max, int machineId) {
				this.allPartsList.add(new InHouse (id, partName, inventoryLevel, cost, min, max, machineId));	
			}
			public void addOutsourcedPartData(int id, String partName, int inventoryLevel, double cost, int min, int max, String companyName) {
				this.allPartsList.add(new Outsourced (id, partName, inventoryLevel, cost, min, max, companyName));	
			}
			
			public void deletePart(String deleteName) {
			this.allPartsList.removeIf(allPartsList -> allPartsList.getPartName().contains(deleteName));
			}
			
			public void deletePart(int selectedId) {
				this.allPartsList.removeIf(allPartsList -> allPartsList.getPartId() == selectedId);
			}
			
			public int getsize() {
				return allPartsList.size();
			}
		
			public Parts getItem(int index) {
				return allPartsList.get(index);
			}
			
			public void setInHousePartData(int index, int id, String partName, int inventoryLevel, int cost, int min, int max, int machineId) {
				this.allPartsList.set(index, new InHouse (id, partName, inventoryLevel, cost, min, max, machineId));	
			}
			
			public void setOutsourcedPartData(int index, int id, String partName, int inventoryLevel, int cost, int min, int max, String companyName) {
				this.allPartsList.set(index, new Outsourced (id, partName, inventoryLevel, cost, min, max, companyName));	
			}

}
