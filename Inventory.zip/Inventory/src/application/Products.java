package application;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleDoubleProperty;
import java.util.*;



public class Products {
	
	private SimpleIntegerProperty productId = new SimpleIntegerProperty(0);
	
	private SimpleStringProperty productName = new SimpleStringProperty("");
	
	private SimpleIntegerProperty inventoryLevelProduct = new SimpleIntegerProperty(0);
	
	private SimpleDoubleProperty costPerUnitProduct = new SimpleDoubleProperty(0);
	
	private SimpleIntegerProperty minProduct = new SimpleIntegerProperty(0);
	
	private SimpleIntegerProperty maxProduct = new SimpleIntegerProperty(0);
	
	private static ObservableList<List<String>> associatedPartsList =
			FXCollections.observableArrayList();

	
//	private static HashMap<String, String> associatedPartsList = new HashMap<String, String>();
	
	public Products() {
		this(0,"",0,0,0,0);
	}
	
	public Products(int productId, String productName, int inventoryLevelProduct, double dp, int mn, int mx) {
		setProductId(productId);
		setProductName(productName);
		setInventoryLevelProd(inventoryLevelProduct);
		setCostPerUnitProd(dp);	
		setMinProd(mn);
		setMaxProd(mx);
	}
	
	public int getProductId() {
		return productId.get();
	}
	
	public void setProductId(int prodId) {
		productId.set(prodId);
	}
	
	public String getProductName() {
		return productName.get();
	}
	
	public void setProductName(String prodName) {
		productName.set(prodName);
	}
	
	public int getInventoryLevelProd() {
		return inventoryLevelProduct.get();
	}
	
	public void setInventoryLevelProd(int iLevelProd) {
		inventoryLevelProduct.set(iLevelProd);
	}
	
	public Double getCostPerUnitProd() {
		return costPerUnitProduct.get();
	}
	
	public void setCostPerUnitProd(Double cPerUnitProd) {
		costPerUnitProduct.set(cPerUnitProd);
	}
	
	public void addAssociatedPart(ArrayList<String> newAssociatedParts) {
		this.associatedPartsList.addAll(newAssociatedParts);
	}
	
	public void deleteAssociatesPart(String selectedPart) {
		associatedPartsList.remove(selectedPart);
	}
	
	public ObservableList<List<String>> getAllAssociatedParts(){
		return associatedPartsList;
	}
	public int getMinProd() {
		return minProduct.get();
	}
	
	public void setMinProd(int mn) {
		minProduct.set(mn);
	}
	
	public int getMaxProd() {
		return maxProduct.get();
	}
	
	public void setMaxProd(int mx) {
		maxProduct.set(mx);
	}
//	public int getAssociatedLength() {
//		return associatedPartsList.size();
//	}
}
