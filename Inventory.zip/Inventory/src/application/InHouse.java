package application;

import javafx.beans.property.SimpleIntegerProperty;

public class InHouse extends Parts{
	
	private SimpleIntegerProperty machineId = new SimpleIntegerProperty(0);
	
	public InHouse() {
		this(0,"",0,0,0,0,0);
	}
	
	public InHouse(int partId, String partName, int inventoryLevel, double d, int min, int max, int machineId) {
		setPartId(partId);
		setPartName(partName);
		setInventoryLevel(inventoryLevel);
		setCostPerUnit(d);
		setMin(min);
		setMax(max);
		setMachineId(machineId);
	}
	
	public int getMachineId() {
		return machineId.get();
	}
	
	public void setMachineId(int macId) {
		machineId.set(macId);

	}
}
