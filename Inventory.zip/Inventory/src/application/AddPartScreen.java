package application;

import java.util.List;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class AddPartScreen {
	
	public Scene sceneView1(Button cancel2, Button savePart) {
		
		PartData partData = new PartData();
		int assignPartId = partData.getPartsList().size();
		//int assignPartId = 4;
				
		//Text objects
		Text addPartText = new Text("Add Part");
		addPartText.setFont(Font.font("Tahoma", 20));
		Text idText = new Text("ID");
		Text nameText = new Text("Name");
		Text invText = new Text("Inv");
		Text costText = new Text("Price/Cost");
		Text maxText = new Text("Max");
		Text minText = new Text("Min");
		Text companyNameText = new Text("Company Name");
		Text machineIdText = new Text("Machine ID");
		
		TextField idTextField = new TextField();
		idTextField.setEditable(false);
		TextField nameTextField = new TextField();
		TextField invTextField = new TextField();
		TextField costTextField = new TextField();
		TextField maxTextField = new TextField();
		TextField minTextField = new TextField();
		TextField companyNameTextField = new TextField();
		TextField machineIdTextField = new TextField();
		
		idTextField.setText(Integer.toString(assignPartId+1));
		nameTextField.setText("Part Name");
		invTextField.setText("Inv");
		costTextField.setText("Price/Cost");
		maxTextField.setText("Max");
		minTextField.setText("Min");
		companyNameTextField.setText("Comp Nm");
		machineIdTextField.setText("Mach ID");
		
		HBox idHb = new HBox();
		HBox nameHb = new HBox();
		HBox invHb = new HBox();
		HBox costHb = new HBox();
		HBox maxHb = new HBox();
		HBox minHb = new HBox();
		HBox companyNameHb = new HBox();
		HBox machineIdHb = new HBox();
		
		idHb.getChildren().addAll(idTextField);
		nameHb.getChildren().addAll(nameTextField);
		invHb.getChildren().addAll(invTextField);
		costHb.getChildren().addAll(costTextField);
		maxHb.getChildren().addAll(maxTextField);
		minHb.getChildren().addAll(minTextField);
		companyNameHb.getChildren().addAll(companyNameTextField);
		machineIdHb.getChildren().addAll(machineIdTextField);
		
		nameHb.setSpacing(10);
		invHb.setSpacing(10);
		costHb.setSpacing(10);
		maxHb.setSpacing(10);
		minHb.setSpacing(10);
		companyNameHb.setSpacing(10);
		machineIdHb.setSpacing(10);
		
		//Buttons
		Button save = new Button("Save");
		//Button warningButton = new Button("Warrning Alert");
		
		//Create an Alert obj
		Alert a = new Alert(AlertType.NONE, "Your Min Exceeds Your Max");
				
		//Radio Buttons
		RadioButton inHouseButton = new RadioButton();
		inHouseButton.setText("In-House");
		inHouseButton.fire();
		
		RadioButton outsourcedButton = new RadioButton();
		outsourcedButton.setText("Outsourced");		
		
		//Grid
		GridPane root = new GridPane();
		
		root.setHgap(10);
		root.setVgap(10);
		root.setPadding(new Insets(25,25,25,25));
		root.setGridLinesVisible(false);
		
		root.add(addPartText, 0,0);
		root.add(inHouseButton, 1, 0);
		root.add(outsourcedButton, 2, 0);
		root.add(idText, 1, 1);
		root.add(idHb, 2, 1);
		root.add(nameText, 1, 2);
		root.add(nameHb, 2, 2);
		root.add(invText, 1, 3);
		root.add(invHb, 2, 3);
		root.add(costText, 1, 4);
		root.add(costHb, 2, 4);
		root.add(maxText, 1, 5);
		root.add(maxHb, 2, 5);
		root.add(minText, 3, 5);
		root.add(minHb, 4, 5);
		root.add(save, 4, 7);
		root.add(cancel2, 5, 7);
		root.add(machineIdText, 1, 6);
		root.add(machineIdHb, 2, 6);
		
		//Radio Button Action
	
		final ToggleGroup group = new ToggleGroup();
		inHouseButton.setToggleGroup(group);
		outsourcedButton.setToggleGroup(group);
		
		group.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov,
					Toggle old_toggle, Toggle new_toggle) {
				if (group.getSelectedToggle() == inHouseButton) {
					root.add(machineIdText, 1, 6);
					root.add(machineIdHb, 2, 6);
					root.getChildren().remove(companyNameText);
					root.getChildren().remove(companyNameHb);
				}
				else {
					root.add(companyNameText, 1, 6);
					root.add(companyNameHb, 2, 6);
					root.getChildren().remove(machineIdText);
					root.getChildren().remove(machineIdHb);
				}
			}
		});
		
		Scene scene = new Scene(root, 700, 500);
		
		//save Part Button Action
				save.setOnAction(e->{
					if (inHouseButton.isSelected()) {
						if( Integer.parseInt(maxTextField.getText())> Integer.parseInt(minTextField.getText())) {
						partData.addInHousePartData(Integer.parseInt(idTextField.getText()), nameTextField.getText(), Integer.parseInt(invTextField.getText()), Integer.parseInt(costTextField.getText()), Integer.parseInt(minTextField.getText()), Integer.parseInt(maxTextField.getText()), Integer.parseInt(machineIdTextField.getText()));
						cancel2.fire();}
						else {
							a.setAlertType(AlertType.WARNING);
							a.show();
						}
						}
					else if (outsourcedButton.isSelected()) {
						if( Integer.parseInt(maxTextField.getText())> Integer.parseInt(minTextField.getText())) {
						partData.addOutsourcedPartData(Integer.parseInt(idTextField.getText()), nameTextField.getText(), Integer.parseInt(invTextField.getText()), Integer.parseInt(costTextField.getText()), Integer.parseInt(minTextField.getText()), Integer.parseInt(maxTextField.getText()), companyNameTextField.getText());
						cancel2.fire();
						}
						else {
							a.setAlertType(AlertType.WARNING);
							a.show();
						}
						};
				});
				
		

		return scene;
	}


}
