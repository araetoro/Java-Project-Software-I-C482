package application;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.*;

public class ModifyProductScreen {

	public Scene sceneView1(Button cancel,int selectedId, String selectedName, int selectedInv, double selectedCost, int selectedMax, int selectedMin) {
	//ModifyProducts Scene Elements
	//Text objects
	Text addProductText = new Text("Modify Product");
	addProductText.setFont(Font.font("Tahoma", 20));
	Text idText = new Text("ID");
	Text nameText = new Text("Name");
	Text invText = new Text("Inv");
	Text costText = new Text("Price");
	Text maxText = new Text("Max");
	Text minText = new Text("Min");

	
	TextField idTextField = new TextField();
	idTextField.setEditable(false);
	TextField searchboxTextField = new TextField();
	TextField nameTextField = new TextField();
	TextField invTextField = new TextField();
	TextField costTextField = new TextField();
	TextField maxTextField = new TextField();
	TextField minTextField = new TextField();

	idTextField.setText(Integer.toString(selectedId));
	nameTextField.setText(selectedName);
	invTextField.setText(Integer.toString(selectedInv));
	costTextField.setText(Double.toString(selectedCost));
	maxTextField.setText(Integer.toString(selectedMax));
	minTextField.setText(Integer.toString(selectedMin));

	HBox idHb = new HBox();
	HBox searchboxHb = new HBox();
	HBox nameHb = new HBox();
	HBox invHb = new HBox();
	HBox costHb = new HBox();
	HBox maxHb = new HBox();
	HBox minHb = new HBox();

	idHb.getChildren().addAll(idTextField);
	searchboxHb.getChildren().addAll(searchboxTextField);
	nameHb.getChildren().addAll(nameTextField);
	invHb.getChildren().addAll(invTextField);
	costHb.getChildren().addAll(costTextField);
	maxHb.getChildren().addAll(maxTextField);
	minHb.getChildren().addAll(minTextField);

	
	searchboxHb.setSpacing(10);
	nameHb.setSpacing(10);
	invHb.setSpacing(5);
	costHb.setSpacing(5);
	maxHb.setSpacing(5);
	minHb.setSpacing(5);
	
//	//Buttons
	Button addButton = new Button();
	addButton.setText("Add");

	Button save = new Button("Save");

	Button deleteButton = new Button("Delete");

	//Add Parts FlowPane
	FlowPane addPartsPane = new FlowPane();
	addPartsPane.setAlignment(Pos.CENTER);
	
	//Add Parts Pane
	PartData partData = new PartData();
	ObservableList<Parts> mpartsList = partData.getPartsList();
//	ObservableList<Parts> partsList = 
//			FXCollections.observableArrayList(
//					new Parts (1,"Part 1",5,5.00),
//					new Parts (2,"Part 2",10,10.00),
//					new Parts (3,"Part 3",12,15.00)
//					);
					
				TableView<Parts> tvAddParts;
				
				tvAddParts = new TableView<Parts>(mpartsList);
				
				TableColumn<Parts, String> pId = new TableColumn<>("Part Id");
				pId.setCellValueFactory(new PropertyValueFactory<>("partId"));
				tvAddParts.getColumns().add(pId);
				
				TableColumn<Parts, String> pName = new TableColumn<>("Part Name");
				pName.setCellValueFactory(new PropertyValueFactory<>("partName"));
				tvAddParts.getColumns().add(pName);
				
				TableColumn<Parts, String> iLevel = new TableColumn<>("Inventory Level");
				iLevel.setCellValueFactory(new PropertyValueFactory<>("inventoryLevel"));
				tvAddParts.getColumns().add(iLevel);
				
				TableColumn<Parts, Double> cPerUnit = new TableColumn<>("Cost Per Unit");
				cPerUnit.setCellValueFactory(new PropertyValueFactory<>("costPerUnit"));
				tvAddParts.getColumns().add(cPerUnit);
				
				tvAddParts.setPrefWidth(325);
				tvAddParts.setPrefHeight(100);
				
				TableView.TableViewSelectionModel<Parts> tvSelParts =
					tvAddParts.getSelectionModel();
				
				
				//Search Products Filter
				FilteredList<Parts> mfilteredParts = new FilteredList<>(mpartsList, p -> true);
				
				searchboxTextField.textProperty().addListener((observable, oldValue, newValue)->{
						mfilteredParts.setPredicate(product ->{
						if(newValue == null || newValue.isEmpty()) {
							return true;
						}
						
						String lowerCaseFilter = newValue.toLowerCase();
					
						if (product.getPartName().toLowerCase().contains(lowerCaseFilter)) {
						return true;
						}
						return false;
						});
					});
					SortedList<Parts> mSortedParts = new SortedList<>(mfilteredParts);
//					tvParts.setItems(sortedParts);
							
					Button searchButton = new Button();
					searchButton.setText("Search");
					searchButton.setOnAction(new EventHandler<ActionEvent>() {
					
					@Override
					public void handle(ActionEvent event) {
						tvAddParts.setItems(mSortedParts);
					}
					
				});	
					addPartsPane.getChildren().addAll(tvAddParts);

		
						
						
						//Associated Parts FlowPane
						FlowPane associatedPartsPane = new FlowPane();
						associatedPartsPane.setAlignment(Pos.CENTER);
						
						//associated Parts Pane						
						Products associatedProd = new Products();
						ObservableList<List<String>> associatedPartsList = associatedProd.getAllAssociatedParts();
												
						//Getting the associated Parts
						ObservableList<Parts> aPartsList = FXCollections.observableArrayList();
						
						for(int i=0 ; i < associatedPartsList.size(); i++) {
							String associatedProduct = selectedName;
							if(associatedPartsList.get(i).contains(associatedProduct)) {
								String associatedPartItem = associatedPartsList.get(i).get(1);
				
								ObservableList<Parts> partList = partData.getPartsList();
								
								for(int j=0; j< partData.getsize();j++) {
								if(partList.get(j).getPartName()==associatedPartItem) {
									Parts aPart = partList.get(j);
									aPartsList.add(aPart);
								}								
								}
							}
						}
						
						
//						ObservableList<Parts> associatedPartsList = 
//								FXCollections.observableArrayList(
//										new Parts (1,"Part 1",5,5.00),
//										new Parts (2,"Part 2",10,10.00),
//										new Parts (3,"Part 3",12,15.00)
//										);
									
									TableView<Parts> tvAssociatedParts;
									
									tvAssociatedParts = new TableView<Parts>(aPartsList);
									
									TableColumn<Parts, String> pIdassociated = new TableColumn<>("Part Id");
									pIdassociated.setCellValueFactory(new PropertyValueFactory<>("partId"));
									tvAssociatedParts.getColumns().add(pIdassociated);
									
									TableColumn<Parts, String> pNameassociated = new TableColumn<>("Part Name");
									pNameassociated.setCellValueFactory(new PropertyValueFactory<>("partName"));
									tvAssociatedParts.getColumns().add(pNameassociated);
									
									TableColumn<Parts, String> iLevelassociated = new TableColumn<>("Inventory Level");
									iLevelassociated.setCellValueFactory(new PropertyValueFactory<>("inventoryLevel"));
									tvAssociatedParts.getColumns().add(iLevelassociated);
									
									TableColumn<Parts, Double> cPerUnitDelte = new TableColumn<>("Cost Per Unit");
									cPerUnitDelte.setCellValueFactory(new PropertyValueFactory<>("costPerUnit"));
									tvAssociatedParts.getColumns().add(cPerUnitDelte);
									
									tvAssociatedParts.setPrefWidth(325);
									tvAssociatedParts.setPrefHeight(100);
									
									TableView.TableViewSelectionModel<Parts> tvSelPartsAssociated =
									tvAssociatedParts.getSelectionModel();
									
									associatedPartsPane.getChildren().addAll(tvAssociatedParts);
											
	

	//Add Part Button Action
	addButton.setOnAction(e->{
	Parts selectedItem = tvAddParts.getSelectionModel().getSelectedItem();
	if(!aPartsList.contains(selectedItem)) {
		aPartsList.add(selectedItem);
	}
	});						
	
	//Delete Product Button Action
	deleteButton.setOnAction(e->{
			Parts selectedItem = tvAssociatedParts.getSelectionModel().getSelectedItem();
			aPartsList.remove(selectedItem);
	});
	
	//Grid
	GridPane root = new GridPane();
	root.setHgap(10);
	root.setVgap(10);
	root.setPadding(new Insets(25,25,25,25));
	root.setGridLinesVisible(false);
			
	root.add(addProductText, 0, 0);
	root.add(idText, 1, 1);
	root.add(idHb, 2, 1);
	root.add(nameText, 1, 2);
	root.add(nameHb, 2, 2);
	root.add(invText, 1, 3);
	root.add(invHb, 2, 3);
	root.add(costText, 1, 4);
	root.add(costHb, 2, 4);
	root.add(maxText, 1, 5);
	root.add(maxHb, 2, 5);
	root.add(minText, 3, 5);
	root.add(minHb, 4, 5);
	root.add(searchButton, 6, 0);
	root.add(searchboxHb, 7, 0,3,1);
	root.add(addPartsPane, 5, 1,5,4);
	root.add(addButton, 11, 5);
	root.add(associatedPartsPane, 5, 6,5,4);
	root.add(deleteButton, 11, 10);
	root.add(save, 10, 11);
	root.add(cancel, 11, 11);
	
	Scene scene = new Scene(root, 1500, 500);
	
	//Create an Alert obj
	Alert a = new Alert(AlertType.NONE, "The Min Exceeds Your Max");
	Alert acost = new Alert(AlertType.NONE, "The Cost Of Your Parts Exeeds The Cost Of Your Product");
	//Save Button Action
	save.setOnAction(e->{
		double totalCost = 0;
		
		for ( Parts item : tvAssociatedParts.getItems()){
			double costPerUnit = item.getCostPerUnit();
			totalCost = totalCost + costPerUnit;
			}

		if(Integer.parseInt(minTextField.getText()) < Integer.parseInt(maxTextField.getText()) & totalCost <=  Double.parseDouble(costTextField.getText())) {
		ProductData prodData = new ProductData();
		Products associatedProddata = new Products();

		int index = selectedId-1;
		
		
		for(int i = 0; i< associatedProddata.getAllAssociatedParts().size() ;i++) {	
			if(associatedProddata.getAllAssociatedParts().get(i).get(0).contains(selectedName)) {
				associatedProddata.getAllAssociatedParts().remove(i);
				i--;	
		}
		
	}


		for ( Parts item : tvAssociatedParts.getItems()){
			String selPartName = item.getPartName();
			ArrayList<String> newAssociatedParts = new ArrayList<String>();
			newAssociatedParts.add(selectedName);
			newAssociatedParts.add(selPartName);
			
			double costPerUnit = item.getCostPerUnit();
			totalCost = totalCost + costPerUnit;
			
			if( !associatedProddata.getAllAssociatedParts().contains(newAssociatedParts)) {
				associatedProddata.addAssociatedPart(newAssociatedParts);
			}

		};

		
		prodData.setProductData(index, selectedId, nameTextField.getText(), Integer.parseInt(invTextField.getText()), Double.parseDouble(costTextField.getText()), Integer.parseInt(minTextField.getText()), Integer.parseInt(maxTextField.getText()));
		cancel.fire();
		}
		else if (Integer.parseInt(minTextField.getText()) > Integer.parseInt(maxTextField.getText())) {
			a.setAlertType(AlertType.WARNING);
			a.show();
		}
		else if (totalCost >=  Double.parseDouble(costTextField.getText())) {
			acost.setAlertType(AlertType.WARNING);
			acost.show();
		}
		});
	
	return scene;
	
	}}